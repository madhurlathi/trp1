package com.trp1.aircomm;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseUtil {
	private static Connection connection = null;
	private static PreparedStatement statement = null;

	public static void createConnection(String tableName) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "admin", "admin");

			// Check whether table already exist
			String sql = "SELECT TNAME FROM TAB WHERE TNAME LIKE '%" + tableName.toUpperCase() + "%'";
			statement = connection.prepareStatement(sql);
			ResultSet resultSet = statement.executeQuery();
			if (!resultSet.next()) {
				sql = "CREATE TABLE " + tableName
						+ " (CUST_ID INT PRIMARY KEY, CUST_NAME VARCHAR2(30), PLAN_TYPE VARCHAR2(1), MONTHLY_CHARGES NUMBER(18,2))";
				statement = connection.prepareStatement(sql);
				if (statement.executeUpdate() == 0) {
					System.out.println("Table created");
				} else {
					System.out.println("Table creation failed!");
				}
			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void inserInDb(String tableName, Customer customer) {
		
		//Create connection
		createConnection(tableName);

		// Insert data
		String sql = "INSERT INTO " + tableName + " (CUST_ID, CUST_NAME, PLAN_TYPE, MONTHLY_CHARGES) VALUES (?,?,?,?)";
		try {
			statement = connection.prepareStatement(sql);
			statement.setInt(1, customer.getCustID());
			statement.setString(2, customer.getCustName());
			statement.setString(3, customer.getPlanType() + "");
			statement.setDouble(4, customer.getMonthlyCharge());
			if (statement.executeUpdate() > 0) {
				System.out.println("Record added in Database!");
			} else {
				System.out.println("Unable to add record in Database!");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		finally {
			try {
				statement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}
}
