package com.trp1.aircomm;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.hssf.util.HSSFColor.ROSE;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class FileUtil {

	public static String SHEET_NAME = "AirComm Customers";

	public static void writeFileData(String fileName, Customer customer) {
		File file = null;
		FileInputStream fileInputStream = null;
		FileOutputStream fileOutputStream = null;
		Workbook workbook = null;
		XSSFSheet sheet = null;
		int lastRow = 0;
		try {
			file = new File(fileName);
			//if file exists open existing one
			if (file.exists()) {
				fileInputStream = new FileInputStream(file);
				workbook = new XSSFWorkbook(fileInputStream);
				sheet = (XSSFSheet) workbook.getSheet(SHEET_NAME);
				lastRow = sheet.getLastRowNum() + 1;

			} 
			// if file not exist create new file
			else {
				workbook = new XSSFWorkbook();
				sheet = (XSSFSheet) workbook.createSheet(SHEET_NAME);

				// template
				Row heading = sheet.createRow(0);

				Cell custId = heading.createCell(0);
				custId.setCellValue("CUSTOMER ID");

				Cell custName = heading.createCell(1);
				custName.setCellValue("NAME");

				Cell planType = heading.createCell(2);
				planType.setCellValue("PLAN TYPE");

				Cell monthlyCharges = heading.createCell(3);
				monthlyCharges.setCellValue("MONTHLY CHARGES");

				lastRow = 1;

			}

			Row data = sheet.createRow(lastRow);

			Cell custId = data.createCell(0);
			custId.setCellValue(customer.getCustID());

			Cell custName = data.createCell(1);
			custName.setCellValue(customer.getCustName());

			Cell planType = data.createCell(2);
			planType.setCellValue(customer.getPlanType()+"");

			Cell monthlyCharges = data.createCell(3);
			monthlyCharges.setCellValue(customer.getMonthlyCharge());

			// write file
			fileOutputStream = new FileOutputStream(file);
			workbook.write(fileOutputStream);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				if (fileInputStream != null) {
					fileInputStream.close();
				}
				if (fileOutputStream != null) {
					fileOutputStream.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public static String readFileData(String fileName) {
		File file = null;
		FileInputStream fileInputStream = null;
		Workbook workbook = null;
		XSSFSheet sheet = null;
		StringBuilder result = null;
		try {
			file = new File(fileName);
			if (!file.exists()) {
				return "File Not Exist!";
			}

			fileInputStream = new FileInputStream(file);
			workbook = new XSSFWorkbook(fileInputStream);
			sheet = (XSSFSheet) workbook.getSheet(SHEET_NAME);
			result = new StringBuilder("");

			for (Row row : sheet) {
				for (Cell cell : row) {
					if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
						result.append(cell.getStringCellValue()).append("\t");
					} else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
						if (cell.getColumnIndex() == 2) {
							result.append((char) cell.getNumericCellValue()).append("\t");
						} else {
							result.append(((Double) cell.getNumericCellValue()).intValue()).append("\t");
						}

					} else if (cell.getCellType() == Cell.CELL_TYPE_BOOLEAN) {
						result.append(cell.getBooleanCellValue()).append("\t");
					}
				}
				result.append("\r\n");
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (fileInputStream != null) {
					fileInputStream.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return result.toString();
	}
}
