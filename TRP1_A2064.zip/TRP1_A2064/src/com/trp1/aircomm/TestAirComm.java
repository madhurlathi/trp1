package com.trp1.aircomm;

public class TestAirComm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Customer customer = new Customer();
		int custId = 101;
		String custName = "ABCDE";
		char planType = 'P';

		try {
			if (!(customer.setCustID(custId))) {
				throw new InvalidDataException("Invalid Cust Id");
			}
			if (!(customer.setCustName(custName))) {
				throw new InvalidDataException("Invalid Customer Name");
			}
			if (!(customer.setPlanType(planType))) {
				throw new InvalidDataException("Invalid Plan Type");
			}
			
			//write data to file
			FileUtil.writeFileData("AirComm.xlsx", customer);
			
			//write data in database
			DatabaseUtil.inserInDb("AirCommCustomers", customer);
			
			//read data from file
			System.out.println(FileUtil.readFileData("AirComm.xlsx"));

		} catch (InvalidDataException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}

	}

}
