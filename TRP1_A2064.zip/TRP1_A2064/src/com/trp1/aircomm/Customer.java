package com.trp1.aircomm;

public class Customer {

	private int custID;
	private String custName;
	private char planType;
	private int monthlyCharge;

	int getCustID() {
		return custID;
	}

	boolean setCustID(int custID) {
		if (custID >= 100 && custID <= 999) {
			this.custID = custID;
			return true;
		} else {
			return false;
		}
	}

	String getCustName() {
		return custName;
	}

	boolean setCustName(String custName) {
		if (custName.length() >= 5) {
			this.custName = custName;
			return true;
		} else {
			return false;
		}

	}

	char getPlanType() {
		return planType;
	}

	boolean setPlanType(char planType) {
		switch (planType) {
		case 'P':
			this.planType = planType;
			this.monthlyCharge = 1000;
			return true;
		case 'G':
			this.planType = planType;
			this.monthlyCharge = 500;
			return true;
		case 'S':
			this.planType = planType;
			this.monthlyCharge = 100;
			return true;
		default:
			return false;
		}

	}

	int getMonthlyCharge() {
		return monthlyCharge;
	}

	@Override
	public String toString() {
		return "Customer [custID=" + custID + ", custName=" + custName + ", planType=" + planType + ", monthlyCharge="
				+ monthlyCharge + "]";
	}
	
}
